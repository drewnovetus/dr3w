# Novetus+ Asset Redirect
 PHP code used for novetus.mygamesonline.org, epicgamers.xyz, and other redirects. Credit goes to fire.
